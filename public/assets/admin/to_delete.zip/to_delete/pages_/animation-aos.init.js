AOS.init({
    easing: "ease-out-back",
    duration: 1e3
});
